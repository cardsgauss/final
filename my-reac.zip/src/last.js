import React from 'react';
import Container from '@material-ui/core/Container';
import Paper from '@material-ui/core/Paper';
import bg from './b.jpg';
import Editing from './editInfo';
import axios from 'axios';
import NavbarPage from './newnav';
class Final extends React.Component {
    constructor(props){
        super(props);
        this.state = { ...Editing.obj };
   
    }
    handleEmail = (event) => {
        event.preventDefault();
        axios.post(`http://localhost:9000/send-mail-attachment`,this.state)
        .then(res => {

                alert("Email sent successfully");
          
        });
    }
    handleProduct = (event) => {
         event.preventDefault();
 
        axios.post(`http://localhost:9000/customer/prod`,this.state)
        .then(res => {

            if (res.data > 0) {
                alert("Credit Card Generated Successfully");
               
                axios.put("http://localhost:9000/app/updatestat/"+encodeURIComponent(this.state.id))
                .then((res) => {
   
                    let path = 'home';
                this.props.history.push(path);
                  
                });
                
            } else {
                alert("Error generating credit card");
            }
        })
    }
    render(){
        return (
            <div>
                <NavbarPage/>
                
            <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
            <Container maxWidth="xl">
            <Paper style={{ marginLeft: "25%", marginRight: "25%",  }}>
            

                <div className="text-center">
                   
                <h2 style={{ textAlign: 'center',paddingTop:"7%"}}> <strong >Congratulations!!!</strong></h2>
                        
                        <form style={{ padding: '20px' }}>
                        <div>
                        <h3 ><strong>Your Credit Card has been generated.</strong><br></br>
                                
                                </h3>
                                
                        </div>
                          <div>
                          <h5 >Send Email to Customer:</h5>
                          <button className="btn btn-success" onClick={this.handleEmail} >Send</button>
                          </div>
                        <br></br>
                        <div>
                        <h5 >Send card to TP system for Printing:</h5>
                        <button onClick={this.handleProduct} className="btn btn-success">Send</button>
                        </div>
                        
                       
                        <br></br>
                        <br></br>
                        </form>
                    
               
            </div>

            </Paper>
            
            </Container>
</div>
</div>

        );

    }
}export default Final;


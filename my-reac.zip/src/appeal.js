import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";

import axios from 'axios';

import editing from './editInfo';

import NavbarPage from './newnav';
class Appeal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }

  }

  componentDidMount() {
    const url = "http://localhost:9000/appeal/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
  }

NextPage=(status,id)=>{
   
  if(status=="Approved")
  {
   axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
   .then((res) => {
      
       editing.obj=res.data;
       let path = 'approval';
   this.props.history.push(path);
   });
  }
  else
  {
   axios.put("http://localhost:9000/app/update/"+encodeURIComponent(id))
   .then((res) => {
       let path = 'home';
   this.props.history.push(path);
     
   });
  }
    
}
  render() {
      
    const columns = [
      {
        Header: "Customer id",
        accessor: "id",
        width:150

      },
      {
        Header: "Customer name",
        accessor: "name",
        width:250
      },
      {
        Header: "Reason ",
        accessor: "reason",
        
        
      }
   
      ,
      {
        Header: "Status ",
        accessor: "status",
        width:150
        
      },
      {
        Header: "Credit score ",
        accessor: "score",
        width:130
      },
      {
        Header: "Actions",
        Cell:props=>{
            return(
                [
                    
                   
        <button className="btn btn-success btn-sm"  style={{marginLeft:10}} onClick={()=>{
            this.NextPage(props.original.status,props.original.id);}}>Next</button>
               
              
                
                ]
            )
        },
        width:150
      }
    ]
    return (
      <div >
            <NavbarPage/>
      <div style={{textAlign:"center",marginTop:20,marginBottom:20}}>
    <h1>Appeal Table</h1>
</div>
      <ReactTable
      style={{marginLeft:50,marginRight:50}}
        columns={columns}
        
        data={this.state.posts}
       defaultPageSize={5}
      filterable
      >
      </ReactTable>
     </div>
    );
  }
}

export default Appeal;

import React, { Component } from 'react';
import './App.css';
import ReactTable from "react-table";
import "react-table/react-table.css";

import axios from 'axios';

import editing from './editInfo';
import bg from './b.jpg';
import { Paper } from '@material-ui/core';
import { Container } from '@material-ui/core';
import { Grid } from '@material-ui/core';

import NavbarPage from './newnav';
class DocumentVerification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: []
      
    }
    this.state = { ...editing.obj };
    

  }

  componentDidMount() {
    const url = "http://localhost:9000/customer/";
    fetch(url, {
      method: "GET"
    }).then(reponse => reponse.json()).then(posts => {
      this.setState({ posts, posts })
    })
   
  }
NextPage=(sup,id)=>{
   if(sup=="Approved")
   {
    axios.get("http://localhost:9000/customer/"+encodeURIComponent(id))
    .then((res) => {
        editing.obj=res.data;
        let path = 'final';
    this.props.history.push(path);
    });
   }
   else
   {
    axios.put("http://localhost:9000/app/update/"+encodeURIComponent(id))
    .then((res) => {
        let path = 'home';
    this.props.history.push(path);
      
    });
   }
}
  render() {
      
    const columns = [
      {
        Header: "Customer id",
        accessor: "id",
        width:150,maxWidth:100,minWidth:100

      },
      {
        Header: "Customer name",
        accessor: "name"
      },
      {
        Header: "Verification by Supervisior",
        accessor: "sup_verification",
       
        
      }
        ,   
      {
        Header: "Actions",
        Cell:props=>{
            return(
                [
                    
                   
        <button className="btn btn-success btn-sm"  style={{marginLeft:10}} onClick={()=>{
            this.NextPage(props.original.sup_verification,props.original.id);}}>Next</button>
               
              
                
                ]
            )
        },
        width:150
      }
    ]
    return (
      <div>
        <NavbarPage/>
        
        <div style={{backgroundImage:"url("+bg +")",backgroundSize:'cover'}}>
        <Paper style={{marginTop:"-20px",marginLeft:"5%",marginRight:"5%"}}>
                <Container maxWidth="xl" style={{marginTop:"10px"}}>
                <Grid>
          <div style={{textAlign:"center",marginBottom:30,marginTop:20,paddingTop:"20px"}}>
        <h1>Document Verification</h1>
    </div>
          <ReactTable
          style={{marginLeft:100,marginRight:100}}
            columns={columns}
            
            data={this.state.posts}
           defaultPageSize={10}
        filterable
          >
          </ReactTable>
          </Grid>
          </Container>
          </Paper>
          </div>
      </div>
     
      
    );
  }
}

export default DocumentVerification;

package com.scb.gauss.dao;

import com.scb.gauss.bean.Login;

public interface LoginDAO {
  public int login(Login a);
}

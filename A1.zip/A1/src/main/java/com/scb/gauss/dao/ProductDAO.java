package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Product;



public interface ProductDAO {
	public List<Product> list();
}

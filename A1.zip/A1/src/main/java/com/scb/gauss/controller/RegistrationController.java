package com.scb.gauss.controller;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.bean.Customer;
import com.scb.gauss.bean.User;
import com.scb.gauss.service.MailService;

@RestController
public class RegistrationController {

	@Autowired
	private MailService notificationService;

	@Autowired
	private User user;


	@PostMapping("send-mail")
	public String send(@RequestBody Customer c) {

		user.setFirstName(c.getName());
		user.setLastName(c.getName());
		user.setEmailAddress(c.getEmail()); //Receiver's email address

		
		try {
			notificationService.sendEmail(user);
		} catch (MailException mailException) {
			System.out.println(mailException);
		}
		return "Congratulations! Your mail has been send to the user.";
	}

	
	@RequestMapping("send-mail-attachment")
	public String sendWithAttachment(@RequestBody Customer c) throws MessagingException {

	
		user.setFirstName("Mukul");
		user.setLastName("Jaiswal");
		user.setEmailAddress(c.getEmail()); //Receiver's email address

	
		try {
			notificationService.sendEmailWithAttachment(user);
		} catch (MailException mailException) {
			System.out.println(mailException);
		}
		return "Congratulations! Your mail has been send to the user.";
	}
}

package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.Appeal;


public interface AppealService {
	public List<Appeal> list();
}

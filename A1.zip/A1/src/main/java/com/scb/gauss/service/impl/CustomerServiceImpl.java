package com.scb.gauss.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.Customer;
import com.scb.gauss.dao.CustomerDAO;
import com.scb.gauss.service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO cusDAO;
	
	static
	{
		System.out.println("In Service");
	}

	@Override
	public int add(Customer customer) {
		return cusDAO.add(customer);
	}
	@Override
	public int product(Customer customer) {
		return cusDAO.product(customer);
	}
	@Override
	public List<Customer> list() {
		return cusDAO.list();
	}
	@Override
	public int delete(int id) {
		return cusDAO.delete(id);
	}
	@Override
	public Customer get(int id) {
		return cusDAO.get(id);
	}
	@Override
	public int update(Customer customer) {
		
		return cusDAO.update(customer);
	}
	@Override
	public int appeal(Customer customer) {
		
		return cusDAO.appeal(customer);
	}
	@Override
	public int appeal1(Customer customer) {
		
		return cusDAO.appeal1(customer);
	}

	@Override
    public int isaadhar(long a) {
         
          return cusDAO.isaadhar(a);
    }
	@Override
	public void docStatus(Customer c) {
		
		cusDAO.docStatus(c);
	}
	@Override
	public void appealStatus(Customer c) {
		
		cusDAO.appealStatus(c);
	}
	@Override
	public void ageStatus(Customer c) {
		
			
			cusDAO.ageStatus(c);		
	}

	

	}



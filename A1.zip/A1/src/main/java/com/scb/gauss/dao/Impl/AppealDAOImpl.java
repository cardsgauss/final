package com.scb.gauss.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.Appeal;
import com.scb.gauss.dao.AppealDAO;


@Repository
public class AppealDAOImpl implements AppealDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public List<Appeal> list(){
	
	String query = "SELECT * FROM appeals";
	return jdbcTemplate.query(query, new AppealMapper());
	}
	
		class AppealMapper implements RowMapper<Appeal> {

			public Appeal mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appeal appeal = new Appeal();
				appeal.setId(rs.getInt("id"));
				appeal.setScore(rs.getInt("score"));
				appeal.setName(rs.getString("name"));
				appeal.setStatus(rs.getString("status"));
				appeal.setReason(rs.getString("reason"));
				return appeal;
			}

		}

	}
